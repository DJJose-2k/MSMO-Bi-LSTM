from keras.applications.vgg19 import preprocess_input, VGG19 as CNN
from keras.models import Model
import numpy as np
import glob,re


# CNN feature extraction
def CNN_based(data):
    FV=[]
    for i in range(len(data)):
        print("CNN :",i)

        base_model = CNN(weights='imagenet')
        # Extract features from an arbitrary intermediate layer like the block4 pooling layer in VGG19
        model = Model(inputs=base_model.input, outputs=base_model.get_layer('block4_pool').output)
        x=data[i]
        x = np.expand_dims(x, axis=0)  # expand the dimension
        # get the features
        x = np.resize(x, (1, 224, 224, 3))  # resize the image to required format
        block4_pool_features = model.predict(x)  # size(1, 14, 14, 512)
        mean_block_feat = block4_pool_features.mean(1)  # (1, 14, 512)
        feature_vec = mean_block_feat.mean(1)  # (1, 512)

        FV.append(feature_vec[0])
        np.savetxt("Processed/CNN_Features_.csv",FV, delimiter=',', fmt='%s')

    return FV




