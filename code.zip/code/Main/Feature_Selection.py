import SMO

def callmain(CNN_Features,feature_size):

    index=SMO.Algm(feature_size)

    SelFeatures=CNN_Features[:,index]

    return SelFeatures
