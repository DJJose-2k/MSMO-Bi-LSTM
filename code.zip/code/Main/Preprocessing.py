from sklearn.preprocessing import MinMaxScaler
import numpy as np

def process(Data):

    scaler = MinMaxScaler()

    normalized_data = scaler.fit_transform(Data)

    normalized_data=np.array(normalized_data)
    return normalized_data