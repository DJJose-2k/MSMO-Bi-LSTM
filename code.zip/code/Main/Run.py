import pandas as pd
import numpy as np
import Preprocessing
import Feature_Selection
import Proposed.BILSTM
import CNN
def callmain(tr):
    ACC,TPR,TNR=[],[],[]

    Input_Data=pd.read_csv('Dataset/water_potability.csv')
    Input_Data=np.array(Input_Data)

    Label=Input_Data[:,-1]
    feature_size=5  # Feature size

    # Preprocessing Input data by using Minmax Normalization
    Pre_data=Preprocessing.process(Input_Data)

    CNN_Features=CNN.CNN_based(Pre_data)  # CNN based Feature Extraction

    Sel_Fea=Feature_Selection.callmain(CNN_Features,feature_size) # Feature selection by using SMO

    Proposed.BILSTM.classify(Sel_Fea,Label,tr,ACC,TPR,TNR)  # Water quality prediction by using BiLSTM

    return ACC,TPR,TNR

