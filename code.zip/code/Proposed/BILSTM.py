from keras.models import Sequential
from keras.layers import Dense, Dropout, Embedding, LSTM, Bidirectional
from sklearn.model_selection import train_test_split
import numpy as np

def classify(Data,Label,tr,ACC,TPR,TNR):

    maxlen = 10

    X_train, X_test, y_train, y_test = train_test_split(Data, Label, train_size=tr)
    nc=len(np.unique(y_train))
    model = Sequential()
    model.add(Embedding(414800, 128, input_length=maxlen))
    model.add(Bidirectional(LSTM(64)))
    model.add(Dropout(0.5))
    model.add(Dense(nc, activation='sigmoid'))
    model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])
    X_test = X_test
    X_test=np.resize(X_test,(len(X_test),10))
    model.fit(X_train,y_train,epochs=10,verbose=0)
    predict = model.predict(np.array(X_test))
    target=y_test
    tp, tn, fn, fp = 0, 0, 0, 0
    uni = np.unique(target)
    for j in range(len(uni)):
        c = uni[j]
        for i in range(len(target)):
            if target[i] == c and predict[i] == c:
                fp += 1
            if target[i] != c and predict[i] != c:
                tn += 1
            if (target[i] == c and predict[i] != c):
                tp += 1
            if (target[i] != c and predict[i] == c):
                fn += 1

    acc = (tp + tn) / (tp + fn + tn + fp)
    tpr = tp / (tp + fn)
    tnr = tn / (tn + fp)

    ACC.append(acc)
    TPR.append(tpr)
    TNR.append(tnr)


